package h;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.NumberFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

// Uncomment if you have iText available (example uses iText 5.x)
// import com.itextpdf.text.*;
// import com.itextpdf.text.pdf.PdfPCell;
// import com.itextpdf.text.pdf.PdfPTable;
// import com.itextpdf.text.pdf.PdfWriter;

public class ElectricityBillApp 
{

    // Paths for simple CSV persistence
    private static final String HISTORY_CSV = "bill_history.csv";

    public static void main(String[] args)
    {
        SwingUtilities.invokeLater(ElectricityBillApp::createAndShow);
    }

    private static void createAndShow()
    {
    	//***********Title****************
        JFrame f = new JFrame("Electricity Bill Calculator");
        f.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        f.setSize(1100, 750);

        // Confirm on exit
        f.addWindowListener(new WindowAdapter()
        {
            @Override
            public void windowClosing(WindowEvent e) 
            {
                int c = JOptionPane.showConfirmDialog(f, "Are you sure you want to exit?", "Confirm Exit",
                        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                if (c == JOptionPane.YES_OPTION) f.dispose();
            }
        });

        // Root panel with GridBagLayout
        JPanel root = new JPanel(new GridBagLayout());
        root.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        f.setContentPane(root);

        // Styling
        UIManager.put("OptionPane.messageFont", new Font("Segoe UI", Font.PLAIN, 14));
        Font labelFont = new Font("Segoe UI", Font.PLAIN, 14);
        Font fieldFont = new Font("Segoe UI", Font.PLAIN, 14);
        Font mono = new Font("Consolas", Font.PLAIN, 14);

        // Components
        JLabel lblTitle = new JLabel("Electricity Bill Calculator");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitle.setForeground(new Color(20, 40, 90));

        JLabel lblName = new JLabel("Customer name:");
        lblName.setFont(labelFont);

        JTextField txtCustomerName = new JTextField(20);
        txtCustomerName.setFont(fieldFont);
        txtCustomerName.setToolTipText("Enter the full customer name (required)");

        JLabel lblMeter = new JLabel("Meter number:");
        lblMeter.setFont(labelFont);

        JTextField txtMeter = new JTextField(20);
        txtMeter.setFont(fieldFont);
        txtMeter.setToolTipText("Enter meter number (e.g., TN-123456). Letters, digits and hyphens allowed");

        JLabel lblUnits = new JLabel("Units consumed:");
        lblUnits.setFont(labelFont);

        JTextField txtUnits = new JTextField(10);
        txtUnits.setFont(fieldFont);
        txtUnits.setToolTipText("Enter non-negative integer units (required)");

        JLabel lblTariff = new JLabel("Tariff type:");
        lblTariff.setFont(labelFont);

        JComboBox<String> cbTariff = new JComboBox<>(new String[]{"Domestic", "Commercial"});
        cbTariff.setFont(fieldFont);
        cbTariff.setToolTipText("Select the tariff category");

        // Charges (optional inputs)
        JLabel lblFixed = new JLabel("Fixed charge (₹):");
        lblFixed.setFont(labelFont);
        JTextField txtFixed = new JTextField("50", 8);
        txtFixed.setFont(fieldFont);
        txtFixed.setToolTipText("Fixed charge per bill (default ₹50)");

        JLabel lblGst = new JLabel("GST (%)");
        lblGst.setFont(labelFont);
        JTextField txtGst = new JTextField("18", 6);
        txtGst.setFont(fieldFont);
        txtGst.setToolTipText("GST percentage applied on energy charge (default 18%)");

        // Result area
        JTextArea txtResult = new JTextArea(10, 35);
        txtResult.setFont(mono);
        txtResult.setEditable(false);
        txtResult.setBorder(BorderFactory.createTitledBorder("Bill summary"));
        JScrollPane resultScroll = new JScrollPane(txtResult);

        // History table with model
        DefaultTableModel model = new DefaultTableModel(new Object[]{
                "Bill ID", "Date/Time", "Name", "Meter", "Tariff", "Units", "Amount (₹)"
        }, 0) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return false;
            }
        };
        JTable tblHistory = new JTable(model);
        tblHistory.setFont(fieldFont);
        tblHistory.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        tblHistory.setRowHeight(24);

        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
        tblHistory.setRowSorter(sorter);

        JScrollPane historyScroll = new JScrollPane(tblHistory);
        historyScroll.setBorder(BorderFactory.createTitledBorder("Bill history"));

        // Filter controls
        JLabel lblFilter = new JLabel("Filter:");
        lblFilter.setFont(labelFont);
        JTextField txtFilter = new JTextField(20);
        txtFilter.setToolTipText("Type to filter by name, meter, tariff, or bill ID");

        // Buttons
        JButton btnCalculate = new JButton("Calculate");
        JButton btnClear = new JButton("Clear");
        JButton btnPrint = new JButton("Print");
        JButton btnExportPdf = new JButton("Export PDF");
        JButton btnDelete = new JButton("Delete Selected");
        JButton btnSaveCsv = new JButton("Save History");
        JButton btnLoadCsv = new JButton("Load History");

        // Tooltips for buttons
        btnCalculate.setToolTipText("Validate inputs and calculate bill");
        btnClear.setToolTipText("Clear the form fields");
        btnPrint.setToolTipText("Print the bill summary");
        btnExportPdf.setToolTipText("Export the bill summary to PDF");
        btnDelete.setToolTipText("Delete selected rows from history");
        btnSaveCsv.setToolTipText("Save bill history to CSV file");
        btnLoadCsv.setToolTipText("Load bill history from CSV file");

        // Optional icons (provide files if you have assets)
        // btnCalculate.setIcon(new ImageIcon("icons/calc.png"));
        // btnPrint.setIcon(new ImageIcon("icons/print.png"));
        // btnExportPdf.setIcon(new ImageIcon("icons/pdf.png"));

        // Layout constraints helper
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Title
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 3;
        root.add(lblTitle, gbc);

        // Form left column
        gbc.gridwidth = 1;

        gbc.gridx = 0; gbc.gridy = 1;
        root.add(lblName, gbc);
        gbc.gridx = 1; gbc.gridy = 1;
        root.add(txtCustomerName, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        root.add(lblMeter, gbc);
        gbc.gridx = 1; gbc.gridy = 2;
        root.add(txtMeter, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        root.add(lblUnits, gbc);
        gbc.gridx = 1; gbc.gridy = 3;
        root.add(txtUnits, gbc);

        gbc.gridx = 0; gbc.gridy = 4;
        root.add(lblTariff, gbc);
        gbc.gridx = 1; gbc.gridy = 4;
        root.add(cbTariff, gbc);

        gbc.gridx = 0; gbc.gridy = 5;
        root.add(lblFixed, gbc);
        gbc.gridx = 1; gbc.gridy = 5;
        root.add(txtFixed, gbc);

        gbc.gridx = 0; gbc.gridy = 6;
        root.add(lblGst, gbc);
        gbc.gridx = 1; gbc.gridy = 6;
        root.add(txtGst, gbc);

        // Buttons column
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        btnPanel.add(btnCalculate);
        btnPanel.add(btnClear);
        btnPanel.add(btnPrint);
        btnPanel.add(btnExportPdf);
        btnPanel.add(btnDelete);
        btnPanel.add(btnSaveCsv);
        btnPanel.add(btnLoadCsv);

        gbc.gridx = 0; gbc.gridy = 7; gbc.gridwidth = 2;
        root.add(btnPanel, gbc);
        gbc.gridwidth = 1;

        // Result area
        gbc.gridx = 0; gbc.gridy = 8; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.BOTH; gbc.weightx = 0.6; gbc.weighty = 0.4;
        root.add(resultScroll, gbc);

        // Right side: filter + table
        JPanel right = new JPanel(new GridBagLayout());
        GridBagConstraints rg = new GridBagConstraints();
        rg.insets = new Insets(6, 6, 6, 6);
        rg.fill = GridBagConstraints.HORIZONTAL;
        rg.anchor = GridBagConstraints.WEST;

        rg.gridx = 0; rg.gridy = 0;
        right.add(lblFilter, rg);
        rg.gridx = 1; rg.gridy = 0;
        right.add(txtFilter, rg);

        rg.gridx = 0; rg.gridy = 1; rg.gridwidth = 2; rg.fill = GridBagConstraints.BOTH; rg.weightx = 1; rg.weighty = 1;
        right.add(historyScroll, rg);

        gbc.gridx = 2; gbc.gridy = 1; gbc.gridheight = 8; gbc.fill = GridBagConstraints.BOTH; gbc.weightx = 0.4; gbc.weighty = 1;
        root.add(right, gbc);

        // Number formatters
        NumberFormat currency = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm");

        // Actions
        btnCalculate.addActionListener(e -> {
            String name = txtCustomerName.getText().trim();
            String meter = txtMeter.getText().trim();
            String unitsStr = txtUnits.getText().trim();
            String tariff = String.valueOf(cbTariff.getSelectedItem());
            String fixedStr = txtFixed.getText().trim();
            String gstStr = txtGst.getText().trim();

            // Validation
            if (name.isEmpty()) {
                showError(f, "Customer name is required.");
                return;
            }
            if (!isValidMeter(meter)) {
                showError(f, "Invalid meter number format. Allowed: letters, digits, hyphen. Example: TN-123456");
                return;
            }
            Integer units = parseNonNegativeInt(unitsStr);
            if (units == null) {
                showError(f, "Units must be a non-negative integer.");
                return;
            }
            Double fixedCharge = parseNonNegativeDouble(fixedStr);
            if (fixedCharge == null) {
                showError(f, "Fixed charge must be a non-negative number.");
                return;
            }
            Double gstPercent = parseNonNegativeDouble(gstStr);
            if (gstPercent == null) {
                showError(f, "GST must be a non-negative number.");
                return;
            }

            // Calculate energy charge using slabs
            double energyCharge = calculateEnergyCharge(units, tariff);

            // GST applied on energy charge
            double gstAmount = energyCharge * (gstPercent / 100.0);

            // Total
            double total = energyCharge + gstAmount + fixedCharge;

            String billId = generateBillId(model);
            String now = LocalDateTime.now().format(dtf);

            // Build summary
            StringBuilder sb = new StringBuilder();
            sb.append("Bill ID    : ").append(billId).append("\n");
            sb.append("Date/Time  : ").append(now).append("\n");
            sb.append("Customer   : ").append(name).append("\n");
            sb.append("Meter      : ").append(meter).append("\n");
            sb.append("Tariff     : ").append(tariff).append("\n");
            sb.append("Units      : ").append(units).append("\n");
            sb.append("----------------------------------------\n");
            sb.append(String.format("Energy     : %s\n", formatINR(energyCharge)));
            sb.append(String.format("GST (%.2f%%): %s\n", gstPercent, formatINR(gstAmount)));
            sb.append(String.format("Fixed      : %s\n", formatINR(fixedCharge)));
            sb.append("----------------------------------------\n");
            sb.append(String.format("Total      : %s\n", formatINR(total)));

            txtResult.setText(sb.toString());

            // Add to history
            model.addRow(new Object[]{billId, now, name, meter, tariff, units, round2(total)});
        });

        btnClear.addActionListener(e -> {
            int c = JOptionPane.showConfirmDialog(f, "Clear all fields and summary?", "Confirm Clear",
                    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (c == JOptionPane.YES_OPTION) {
                txtCustomerName.setText("");
                txtMeter.setText("");
                txtUnits.setText("");
                txtFixed.setText("50");
                txtGst.setText("18");
                txtResult.setText("");
                cbTariff.setSelectedIndex(0);
                txtCustomerName.requestFocus();
            }
        });

        btnPrint.addActionListener(e -> {
            try {
                boolean ok = txtResult.print();
                if (!ok) showInfo(f, "Print cancelled.");
            } catch (Exception ex) {
                showError(f, "Print failed: " + ex.getMessage());
            }
        });

        btnExportPdf.addActionListener(e -> {
            if (txtResult.getText().trim().isEmpty()) {
                showInfo(f, "No bill summary to export. Please calculate first.");
                return;
            }
            JFileChooser chooser = new JFileChooser();
            chooser.setSelectedFile(new File("bill_summary.pdf"));
            int res = chooser.showSaveDialog(f);
            if (res == JFileChooser.APPROVE_OPTION) {
                File file = chooser.getSelectedFile();
                try {
                    exportPdfSimple(file.getAbsolutePath(), txtResult.getText());
                    showInfo(f, "PDF exported: " + file.getAbsolutePath());
                } catch (Exception ex) {
                    showError(f, "PDF export failed: " + ex.getMessage());
                }
            }
        });

        btnDelete.addActionListener(e -> {
            int[] selected = tblHistory.getSelectedRows();
            if (selected.length == 0) {
                showInfo(f, "Select row(s) to delete from history.");
                return;
            }
            int c = JOptionPane.showConfirmDialog(f, "Delete selected row(s)?", "Confirm Delete",
                    JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (c == JOptionPane.YES_OPTION) {
                // Adjust for sorter
                for (int i = selected.length - 1; i >= 0; i--) {
                    model.removeRow(tblHistory.convertRowIndexToModel(selected[i]));
                }
            }
        });

        txtFilter.getDocument().addDocumentListener(new SimpleDocumentListener(() -> {
            String text = txtFilter.getText().trim();
            if (text.isEmpty()) {
                sorter.setRowFilter(null);
            } else {
                sorter.setRowFilter(RowFilter.regexFilter("(?i)" + PatternUtil.escape(text)));
            }
        }));

        btnSaveCsv.addActionListener(e -> {
            try {
                saveHistoryCsv(model, HISTORY_CSV);
                showInfo(f, "History saved to: " + HISTORY_CSV);
            } catch (Exception ex) {
                showError(f, "Save failed: " + ex.getMessage());
            }
        });

        btnLoadCsv.addActionListener(e -> {
            try {
                loadHistoryCsv(model, HISTORY_CSV);
                showInfo(f, "History loaded from: " + HISTORY_CSV);
            } catch (Exception ex) {
                showError(f, "Load failed: " + ex.getMessage());
            }
        });

        // Show frame
        f.setLocationRelativeTo(null);
        f.setVisible(true);
    }

    // -------- Helpers --------

    private static boolean isValidMeter(String meter) {
        if (meter == null || meter.trim().isEmpty()) return false;
        // Letters, digits, hyphen, length 3-20
        return meter.matches("[A-Za-z0-9-]{3,20}");
    }

    private static Integer parseNonNegativeInt(String s) {
        try {
            int val = Integer.parseInt(s.trim());
            if (val < 0) return null;
            return val;
        } catch (Exception e) {
            return null;
        }
    }

    private static Double parseNonNegativeDouble(String s) {
        try {
            double val = Double.parseDouble(s.trim());
            if (val < 0) return null;
            return val;
        } catch (Exception e) {
            return null;
        }
    }

    // Slab-based energy charge
    private static double calculateEnergyCharge(int units, String tariff) {
        double charge = 0.0;
        if ("Domestic".equalsIgnoreCase(tariff)) {
            // Example slabs:
            // 0–100: ₹3/unit
            // 101–300: ₹5/unit
            // 301+: ₹8/unit
            int u = units;
            int slab1 = Math.min(u, 100);
            charge += slab1 * 3.0;
            u -= slab1;
            if (u > 0) {
                int slab2 = Math.min(u, 200);
                charge += slab2 * 5.0;
                u -= slab2;
            }
            if (u > 0) {
                charge += u * 8.0;
            }
        } else {
            // Commercial (simple example): flat ₹10/unit
            charge = units * 10.0;
        }
        return round2(charge);
    }

    private static String generateBillId(DefaultTableModel model) {
        int next = model.getRowCount() + 1;
        return "BILL-" + LocalDateTime.now().getYear() + "-" + String.format("%04d", next);
    }

    private static String formatINR(double amount) {
        // Without currency symbol to keep alignment consistent
        return String.format("₹ %.2f", amount);
    }

    private static double round2(double v) {
        return Math.round(v * 100.0) / 100.0;
    }

    private static void showError(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private static void showInfo(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, msg, "Info", JOptionPane.INFORMATION_MESSAGE);
    }

    // PDF export: simple text dump; replace with table-based iText as desired
    private static void exportPdfSimple(String path, String content) throws Exception {
        // Option A: iText (uncomment imports and use below)
        /*
        Document doc = new Document(PageSize.A4);
        PdfWriter.getInstance(doc, new FileOutputStream(path));
        doc.open();
        Font font = FontFactory.getFont(FontFactory.COURIER, 11, BaseColor.BLACK);
        for (String line : content.split("\\R")) {
            Paragraph p = new Paragraph(line, font);
            p.setSpacingAfter(4);
            doc.add(p);
        }
        doc.close();
        */

        // Option B: Fallback — write a .txt disguised as .pdf (not a real PDF)
        // Replace with iText when available.
        try (Writer w = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(path), "UTF-8"))) {
            w.write(content);
        }
    }

    private static void saveHistoryCsv(DefaultTableModel model, String path) throws IOException {
        try (BufferedWriter bw = Files.newBufferedWriter(Paths.get(path))) {
            // Header
            bw.write("Bill ID,Date/Time,Name,Meter,Tariff,Units,Amount");
            bw.newLine();
            for (int r = 0; r < model.getRowCount(); r++) {
                StringBuilder sb = new StringBuilder();
                for (int c = 0; c < model.getColumnCount(); c++) {
                    Object val = model.getValueAt(r, c);
                    sb.append(escapeCsv(val == null ? "" : val.toString()));
                    if (c < model.getColumnCount() - 1) sb.append(",");
                }
                bw.write(sb.toString());
                bw.newLine();
            }
        }
    }

    private static void loadHistoryCsv(DefaultTableModel model, String path) throws IOException {
        if (!Files.exists(Paths.get(path))) throw new FileNotFoundException("File not found: " + path);
        // Clear existing
        model.setRowCount(0);
        try (BufferedReader br = Files.newBufferedReader(Paths.get(path))) {
            String line;
            boolean first = true;
            while ((line = br.readLine()) != null) {
                if (first) { first = false; continue; } // skip header
                String[] cols = parseCsvLine(line);
                if (cols.length >= 7) {
                    model.addRow(new Object[]{cols[0], cols[1], cols[2], cols[3], cols[4], parseNonNegativeInt(cols[5]), Double.valueOf(cols[6])});
                }
            }
        }
    }

    // CSV helpers
    private static String escapeCsv(String s) {
        if (s.contains(",") || s.contains("\"") || s.contains("\n") || s.contains("\r")) {
            s = s.replace("\"", "\"\"");
            return "\"" + s + "\"";
        }
        return s;
    }

    private static String[] parseCsvLine(String line) {
        // Simple CSV parse supporting quotes
        java.util.List<String> tokens = new java.util.ArrayList<>();
        StringBuilder sb = new StringBuilder();
        boolean inQuotes = false;
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (inQuotes) {
                if (ch == '\"') {
                    if (i + 1 < line.length() && line.charAt(i + 1) == '\"') {
                        sb.append('\"'); i++;
                    } else {
                        inQuotes = false;
                    }
                } else {
                    sb.append(ch);
                }
            } else {
                if (ch == '\"') {
                    inQuotes = true;
                } else if (ch == ',') {
                    tokens.add(sb.toString());
                    sb.setLength(0);
                } else {
                    sb.append(ch);
                }
            }
        }
        tokens.add(sb.toString());
        return tokens.toArray(new String[0]);
    }

    // Simple document listener utility
    private interface ChangeHandler { void changed(); }
    private static class SimpleDocumentListener implements javax.swing.event.DocumentListener {
        private final ChangeHandler handler;
        SimpleDocumentListener(ChangeHandler h) { this.handler = h; }
        @Override public void insertUpdate(javax.swing.event.DocumentEvent e) { handler.changed(); }
        @Override public void removeUpdate(javax.swing.event.DocumentEvent e) { handler.changed(); }
        @Override public void changedUpdate(javax.swing.event.DocumentEvent e) { handler.changed(); }
    }

    // Pattern escape for regex filter
    private static class PatternUtil {
        static String escape(String s) {
            return s.replaceAll("([\\\\.\\[\\]\\{\\}\\(\\)\\*\\+\\?\\^\\$\\|])", "\\\\$1");
        }
    }
}